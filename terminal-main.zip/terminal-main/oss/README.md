### Component-Governance-tracked OSS dependencies

This directory contains mirrored open-source projects that are used by the
console host and Windows Terminal. Code in this directory will be replicated
into the Windows OS repository.

All projects in this directory **must** bear Component Governance Manifests
(`cgmanifest.json` files) indicating their provenance.
