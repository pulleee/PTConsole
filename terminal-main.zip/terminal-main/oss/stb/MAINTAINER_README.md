### Notes for Future Maintainers

Search for files prefixed with `stb_` in this project.
At the time of writing, the only file being used is `stb_rect_pack.h`.
