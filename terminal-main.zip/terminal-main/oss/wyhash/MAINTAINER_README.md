### Notes for Future Maintainers

[wyhash](https://github.com/wangyi-fudan/wyhash) is used as the hash algorithm for `<til/hash.h>` and its `til::hasher`.
The source code was directly integrated into that header file and can be found in `/src/inc/til/hash.h`.
