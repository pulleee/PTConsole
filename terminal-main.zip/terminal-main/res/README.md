# Windows Terminal and Console Assets

## Images

The images in this directory do not fall under the same [license](https://raw.githubusercontent.com/microsoft/terminal/main/LICENSE) as the rest
of the Windows Terminal code.

Please consult the [license](./LICENSE) in this directory for terms applicable to the image assets in this directory.
