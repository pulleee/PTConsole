# Windows Terminal and Console Assets (Fonts)

The fonts in this directory do not fall under the same [license](https://raw.githubusercontent.com/microsoft/terminal/main/LICENSE) as the rest
of the Windows Terminal code.

Please consult the [license](https://raw.githubusercontent.com/microsoft/cascadia-code/main/LICENSE) in the
[microsoft/cascadia-code](https://github.com/microsoft/cascadia-code) repository for terms applicable to the fonts in this directory.

### Fonts Included

* Cascadia Code, Cascadia Mono (2407.24)
   * from microsoft/cascadia-code@56bcca3f2c1e4cb19458954f0e2bb4635960df91
