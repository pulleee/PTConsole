// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#include "pch.h"

#include "MySettings.h"
#include "MySettings.g.cpp"

namespace winrt::SampleApp::implementation
{
}
