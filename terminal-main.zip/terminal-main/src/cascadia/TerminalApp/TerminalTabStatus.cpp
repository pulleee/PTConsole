// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#include "pch.h"
#include "TerminalTabStatus.h"
#include "TerminalTabStatus.g.cpp"

namespace winrt::TerminalApp::implementation
{
}
