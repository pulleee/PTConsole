// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#pragma once

inline constexpr std::wstring_view AzureClientID{ L"245e1dee-74ef-4257-a8c8-8208296e1dfd" };
